/* copyright(c) WEBsiting.co.kr */

	setTimeout(function () {
		history.back();;
	}, 1000);
