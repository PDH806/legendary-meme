Theme Name: PURE WHITE(퓨어화이트)
Theme URI: https://sir-purewhite.websiting.kr
Maker: 웹사이팅
Maker URI: https://websiting.kr
Version: 5.6.13
Detail: PURE WHITE(퓨어화이트) 테마는  웹사이팅에서 판매하는 그누보드5용 테마입니다. 라이센스 구입 후 사용하시기 바랍니다. (테마 버전과 동일한 그누보드5버전에서 정상 작동 됩니다.)
License: 1도메인 1카피 (서브도메인 각각 개별 적용)
License URI: https://sir.websiting.kr/lisense.html